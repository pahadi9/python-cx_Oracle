Chapter 4
=========

Run:

    $ make

to generate all images and

    $ make clean

to delete the generated PNG files.
