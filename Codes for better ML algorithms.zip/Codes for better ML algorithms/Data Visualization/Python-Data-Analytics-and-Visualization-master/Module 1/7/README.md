README
======

Chapter 7 code.

The `analysis.py` files contains code from the chapter.

The files:

* clean_rbrted.py
* makedata.py

are helper scripts to clean some messy CSV ("Filtering") or to
generate data ("Data Aggregation").